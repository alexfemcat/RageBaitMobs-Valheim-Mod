# Viking Ragebait — Client Install

This bundle is for **players joining a server that already has the mod installed**, or for anyone hosting locally via the in-game "Start Game" host option.

The client doesn't talk to the LLM directly — it just detects events (you got hit, a mob saw you) and sends a tiny RPC to the server. Without the client mod, you can still join a modded server, but:

| | Modded client | Vanilla client |
|---|---|---|
| Roasts triggered when *you* get hit | Yes | **No** (only events from modded clients trigger roasts) |
| Speech bubble above the mob's head | Yes | No |
| Insults visible in chat | Yes | Yes (server falls back to chat for vanilla) |

Install this if you want the full experience: speech bubbles, every event triggers, kill-count shame.

---

## Requirements

- **Valheim** retail install (Steam, GamePass, etc.). Tested on `l-0.221.12` (network version 36).
- **BepInEx** 5.4.x for Valheim. Get the most recent build here: https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/
- **No LM Studio needed on the client.** Only the server host runs LM Studio.

---

## Install — Step by step

### 1. Install BepInEx (if you don't have it)

If you've ever installed any Valheim mod before, you already have BepInEx. Skip to step 2.

If not:
1. Download `BepInExPack_Valheim` from Thunderstore (link above).
2. Unzip the contents directly into your Valheim install folder (the folder containing `valheim.exe` or the `valheim.x86_64` Linux launcher). The unzip should leave you with `BepInEx/`, `doorstop_libs/`, etc. sitting next to the launcher.

**Where is the Valheim install folder?**

| Platform | Default path |
|---|---|
| Windows (Steam) | `C:\Program Files (x86)\Steam\steamapps\common\Valheim\` |
| Linux (Steam) | `~/.steam/steam/steamapps/common/Valheim/` or `~/.local/share/Steam/steamapps/common/Valheim/` |
| Linux (Debian Steam) | `~/.steam/debian-installation/steamapps/common/Valheim/` |
| Mac (Steam) | `~/Library/Application Support/Steam/steamapps/common/Valheim/` |

3. Launch Valheim once. BepInEx generates its `BepInEx/config/`, `BepInEx/cache/`, and `BepInEx/LogOutput.log` files. Quit the game.

### 2. Install Viking Ragebait

1. Locate your `BepInEx/plugins/` folder inside the Valheim install dir (see paths above).
2. Copy the entire `RagebateMobs/` folder from this zip into `BepInEx/plugins/`.

Final layout:

```
<Valheim install>/
└── BepInEx/
    ├── plugins/
    │   └── RagebateMobs/        <-- you put this here
    │       ├── RagebateMobs.dll
    │       └── Newtonsoft.Json.dll
    ├── config/
    └── core/
```

### 3. Launch the game

Start Valheim normally. The mod loads automatically. To verify, check `BepInEx/LogOutput.log` and look for:

```
[Info   :   BepInEx] Loading [Viking Ragebait 1.0.0]
[Info   :Viking Ragebait] Loaded. API: http://localhost:1234/v1
[Info   :Viking Ragebait] [Ragebait] Registered RPCs: RagebateMobs_RequestRoast, RagebateMobs_RoastBroadcast
```

You're good. Join your modded server, get hit by a Greydwarf, hear yourself called a whole L my G.

---

## Configuration (optional)

The first time the mod runs it generates `BepInEx/config/com.valheim.ragebatemobs.cfg`. **As a client you don't need to edit this** — all gameplay-affecting settings (intensity, cooldowns, model) are controlled by the server. The client config exists because the same DLL serves both roles, but the client only reads `Enabled`.

If you want to disable the mod without uninstalling, set `Enabled = false` in that file.

---

## Local hosting (in-game "Start Game" / "Start World" with friends)

If you're hosting a world from inside the game (not running a dedicated server) AND you want roasts to fire, **you also need to install LM Studio on your machine** and run it before launching Valheim. Your machine becomes "the server host" in the architecture diagram. See the **Server bundle** README for LM Studio setup — the steps are the same.

For dedicated server setups, only the server box needs LM Studio. Players install just the client bundle.

---

## Troubleshooting

**Mod doesn't load. No `[Viking Ragebait]` lines in LogOutput.log.**
- Confirm BepInEx itself is loaded — you should see `[BepInEx] BepInEx 5.x.x ... loaded` near the top of `LogOutput.log`. If not, BepInEx isn't installed correctly.
- Confirm the folder is named exactly `RagebateMobs` and contains both DLLs.

**Mod loads but I never see speech bubbles / insults.**
- The server probably doesn't have the mod, or its LM Studio isn't running. Check with the server admin.
- If you're hosting locally, see the local hosting note above.

**`Could not load file or assembly 'Newtonsoft.Json'`.**
- `Newtonsoft.Json.dll` must sit next to `RagebateMobs.dll` inside the `RagebateMobs/` plugin folder. Don't put it loose in `plugins/`.

**Crossplay / friends on different platforms.**
- Custom routed RPCs aren't part of Valheim's version handshake. A vanilla client (no mod) can join a modded server fine; they just won't trigger roasts and will see insults in chat instead of as bubbles. This is by design.

---

## Uninstall

Delete the `BepInEx/plugins/RagebateMobs/` folder. Optionally also delete `BepInEx/config/com.valheim.ragebatemobs.cfg`. The game returns to vanilla.
