# Viking Ragebait — Server Install

This bundle is for the **server host** — the machine that runs the dedicated server (or hosts the world if you use in-game "Start Game"). The server is the **only** machine that talks to LM Studio. All clients route their events to the server, the server generates the insult, and the server broadcasts it back.

If you're a player just joining a modded server, install the **client bundle** instead.

---

## Architecture (so you know what's running where)

```
[Player's modded client]      [Your server box]              [All clients]
event detected                 receives RPC
        │                      cooldown / dedup
        │  RPC ──────────────▶ calls LM Studio (localhost)
                                        │
                                        ▼
                                broadcast ──────▶ speech bubble (modded)
                                            └──▶ chat message  (vanilla)
```

The server box must be running:
- The Valheim dedicated server (or the "host" instance from in-game)
- BepInEx with this mod installed
- LM Studio with a model loaded and the local API server started

---

## Requirements

- **Valheim dedicated server** binary (Linux or Windows). Available via SteamCMD app id `896660` or the in-game host.
- **BepInEx 5.4.x for Valheim**. Use the **Unix** build for Linux servers (`denikson-BepInExPack_Valheim` works on both Linux and Windows but make sure to use the Unix variant on Linux).
  - https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/
- **LM Studio** on the same box: https://lmstudio.ai
- A model. **Use an uncensored / abliterated instruct model** — vanilla RLHF models will refuse to roast and you'll get empty completions.
  - Default expected: `meta-llama-3.1-8b-instruct-abliterated`
  - Smaller and faster alternatives that still work: `gemma-3-1b-it-abliterated`, `ministral-3b-instruct-abliterated`
  - Anything ~7-8B uncensored on a single GPU is the sweet spot.

---

## Install — Step by step

### 1. Install BepInEx on the server

If you've already modded the server, skip ahead.

1. Download `BepInExPack_Valheim` from Thunderstore (link above). On Linux, follow the Unix install instructions inside the pack — there's a `start_server_bepinex.sh` you'll need to run instead of the vanilla `start_server.sh`.
2. Drop the BepInEx files next to the dedicated server binary.
3. Run the BepInEx-wrapped start script once to generate `BepInEx/config/`, `BepInEx/plugins/`, etc., then stop the server.

### 2. Install Viking Ragebait

1. Find `BepInEx/plugins/` inside your dedicated server install.
2. Copy the entire `RagebateMobs/` folder from this zip into `BepInEx/plugins/`.

Final layout:

```
<server install>/
├── valheim_server.x86_64           (Linux dedicated server binary)
├── start_server_bepinex.sh
├── BepInEx/
│   ├── plugins/
│   │   └── RagebateMobs/           <-- you put this here
│   │       ├── RagebateMobs.dll
│   │       └── Newtonsoft.Json.dll
│   ├── config/
│   └── core/
```

### 3. Install and start LM Studio

1. Download and install LM Studio from https://lmstudio.ai. There's a Linux AppImage, a Windows installer, and a Mac DMG.
2. Open LM Studio, search for and download a model. Recommended: `meta-llama-3.1-8b-instruct-abliterated` (~5 GB, runs on a single 8GB+ GPU).
3. Load the model.
4. Start the local server: click "Start Server" in the LM Studio GUI, OR from CLI:
   ```
   lms server start
   ```
   Default endpoint: `http://localhost:1234/v1`. The mod expects the `/v1` suffix.
5. Verify it's reachable:
   ```
   curl http://localhost:1234/v1/models
   ```
   Should return a JSON blob listing the loaded model.

**Important:** LM Studio must keep running while the Valheim server is up. If you reboot the box, you have to start LM Studio + load model + start its API server again before launching Valheim. Consider scripting it.

### 4. Start the dedicated server

Run your normal BepInEx-wrapped start script. On first launch the mod generates `BepInEx/config/com.valheim.ragebatemobs.cfg`. Watch the log:

```
[Info   :   BepInEx] Loading [Viking Ragebait 1.0.0]
[Info   :Viking Ragebait] Loaded. API: http://localhost:1234/v1
[Info   :Viking Ragebait] [Ragebait] Registered RPCs: RagebateMobs_RequestRoast, RagebateMobs_RoastBroadcast
[Info   :Viking Ragebait] [Ragebait] Patched MonsterAI.DoAttack
[Info   :Viking Ragebait] [Ragebait] Patched Character.ApplyDamage
[Info   :Viking Ragebait] [Ragebait] Patched Character.ApplyDamage (death)
[Info   :Viking Ragebait] [Ragebait] Patched Character.ApplyDamage (mob death)
[Info   :Viking Ragebait] [Ragebait] Patched Character.ApplyDamage (low-hp hype)
[Info   :Viking Ragebait] [Ragebait] Patched ZNet.Awake
```

Stop the server, edit the config (next section), restart.

---

## Configuration

Edit `BepInEx/config/com.valheim.ragebatemobs.cfg`:

```ini
[General]
Enabled = true            # master kill switch
InsultIntensity = Normal  # Mild, Normal, Spicy, or XXXtreme

[API]
LLMModel = meta-llama-3.1-8b-instruct-abliterated
LMStudioApiUrl = http://localhost:1234/v1   # MUST include /v1

[Cooldowns]
PerMobCooldownSeconds = 10   # same mob waits N seconds before roasting again
MaxSimultaneousInsults = 5   # cap on concurrent LLM calls

[Triggers]
MinDamageThreshold = 5       # took_damage trigger fires only for hits >= this much

[Debug]
DebugLogging = false
```

### Insult intensity tiers

- **Mild** — playful teasing, no swearing, family-friendly
- **Normal** — standard ragebait, some swearing (default)
- **Spicy** — heavy swearing, genuinely hostile
- **XXXtreme** — no restrictions, 2 sentences allowed, slurs and discriminatory language permitted. **Don't ship this on a public server unless your players have explicitly opted in.**

### Kill-count persistence

`BepInEx/config/ragebatemobs_kills.json` is generated on first kill. It tracks how many times each player has died to each mob type — the prompt builder uses this for "shame" context ("This loser has died to you 47 times now"). Safe to delete to reset stats.

---

## What's in the mod (so you know what to expect)

**Triggers** — these all fire on the modded client and route to the server:
- `spotted_player` — mob first targets a player
- `took_damage` — player takes a hit ≥ `MinDamageThreshold`
- `player_died` — player killed by a mob
- `player_killed_mob` — mob killed by a player (mob delivers in-character last words)
- `hype_man` — when a mob drops below 30% HP, a nearby same-type buddy fires off a defending insult
- Call-and-response — buddy mobs within 20m chain follow-up roasts ~1.5s after the original
- Rivalries — rival species (Greydwarf↔Skeleton, Draugr↔Wraith, Goblin↔Wolf) trash-talk each other when both nearby
- Betting — same-type bystander mobs sometimes place bets on the fight outcome and gloat/whine when it resolves

**Personalities** — 24+ mob types with distinct voices: Troll (American bro), Greydwarf (AAVE hood gang slang), Draugr (British Chav), Wraith (Victorian ghost), Wolf (oracle), Surtling (fire puns), etc. See `src/Services/PromptBuilder.cs` if you want to tweak.

---

## Soft dependency / Crossplay

Custom routed RPCs are not part of Valheim's version handshake. Vanilla clients can join a modded server fine, including over crossplay (Steam ↔ PlayFab). They simply don't have the RPC handlers, so:
- Vanilla clients don't trigger roasts (no client-side detection)
- Vanilla clients don't render bubbles
- Server falls back to sending vanilla `ChatMessage` RPC to vanilla clients so they at least see the insult in chat

If every player should get the full bubble experience, share the **client bundle** with them.

---

## Performance

- LLM calls are fully fire-and-forget; they never block the server tick. If LM Studio is offline or slow, the request just times out silently.
- Concurrent requests are capped by `MaxSimultaneousInsults` (default 5) via a semaphore — no thundering-herd on the LLM.
- Per-mob cooldown (`PerMobCooldownSeconds`) prevents the same skeleton from spamming.
- Group cooldowns (per mob type, hardcoded): 30s call-response, 45s rivalry, 20s hype, 60s bet.

---

## Troubleshooting

**`Could not load file or assembly 'Newtonsoft.Json'`.**
- `Newtonsoft.Json.dll` must sit next to `RagebateMobs.dll` inside the `RagebateMobs/` plugin folder. Both go in the same folder.

**`Empty insult from LLM`.**
- The model returned a blank/refused completion. This is almost always a vanilla RLHF-tuned model refusing the prompt. Switch to an abliterated/uncensored variant.

**`Failed to connect to LM Studio` / connection errors.**
- LM Studio isn't running, or `LMStudioApiUrl` in the config is wrong, or the URL is missing the `/v1` suffix. Default should be `http://localhost:1234/v1`.
- If LM Studio is running on a different machine, put its IP/port here. Port 1234 must be open on the LM Studio host.

**Insults are too long / wall of text.**
- Increase intensity tier — the prompt enforces tighter limits at lower tiers.
- Use a smaller / less verbose model. 1B–3B abliterated models tend to stay short.

**Mod loads on server but no roasts ever fire.**
- Players need either the client mod (full experience) OR they need to be the only modded client. Trigger detection is client-side. Check `BepInEx/LogOutput.log` on the server — if you don't see `[Ragebait] {mobName} -> {playerName} ({triggerType}) requested by peer ...` lines, no client is sending events.

**Patches fail with HarmonyX errors after a Valheim update.**
- A Valheim update may have renamed or moved a method. Check `src/Patches/` and rebuild. The patches are isolated, so one failed patch won't take down the others.

---

## Uninstall

Stop the server. Delete `BepInEx/plugins/RagebateMobs/`. Optionally also delete `BepInEx/config/com.valheim.ragebatemobs.cfg` and `BepInEx/config/ragebatemobs_kills.json`. Restart. Done.

---

## Source / build from source

Source: https://github.com/alexfemcat/RageBaitMobs-Valheim-Mod

```
dotnet build RagebateMobs.csproj -c Release
```

Output ends up at `bin/Release/net472/net472/RagebateMobs.dll` with `Newtonsoft.Json.dll` next to it.
